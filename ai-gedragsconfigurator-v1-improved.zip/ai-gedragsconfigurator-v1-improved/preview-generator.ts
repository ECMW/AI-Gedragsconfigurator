/**
 * Preview Generator - genereert een expliciet gesimuleerde gedragspreview.
 *
 * Dit is géén modeluitvoer en géén voorspelling van exact toekomstig gedrag.
 * Het doel is uitsluitend om zichtbaar te maken welke richting de configuratie geeft.
 */

import { BehaviorModel } from './gedragsmodel';

export interface ConversationMessage {
  role: 'user' | 'assistant';
  content: string;
}

const DEMO_QUESTION = 'Ik begrijp het verschil tussen correlatie en causaliteit nog niet. Kun je me helpen?';

export function generatePreviewConversation(behavior: BehaviorModel): ConversationMessage[] {
  return [
    { role: 'user', content: DEMO_QUESTION },
    { role: 'assistant', content: generateAIResponse(behavior) },
  ];
}

function generateAIResponse(behavior: BehaviorModel): string {
  const parts: string[] = [];

  if (behavior.responseType <= 30) {
    parts.push('Zeker. Laten we beginnen met jouw eigen redenering: als twee dingen tegelijk veranderen, weet je dan automatisch dat het ene het andere veroorzaakt?');
  } else if (behavior.responseType >= 70) {
    parts.push('Zeker. Correlatie betekent dat twee verschijnselen samen veranderen; causaliteit betekent dat het ene verschijnsel daadwerkelijk bijdraagt aan het ontstaan van het andere.');
  } else {
    parts.push('Zeker. Kort gezegd: correlatie is samenhang, causaliteit is oorzaak-gevolg. Kun je een voorbeeld bedenken waarin twee dingen samen veranderen zonder dat het ene de oorzaak is van het andere?');
  }

  if (behavior.practicality >= 65) {
    parts.push('Denk bijvoorbeeld aan ijsverkoop en zonnebrand: beide nemen toe bij warm weer, maar ijsverkoop veroorzaakt geen zonnebrand.');
  } else if (behavior.practicality <= 35) {
    parts.push('Het onderscheid draait om de vraag of een waargenomen samenhang ook een geloofwaardig mechanisme en voldoende bewijs voor een oorzakelijk verband heeft.');
  }

  if (behavior.consensus <= 30) {
    parts.push('Kritische check: welke derde factor zou een schijnbaar verband kunnen verklaren?');
  }

  if (behavior.discovery >= 70) {
    parts.push('Probeer nu zelf één voorbeeld te geven van correlatie zonder causaliteit; ik reageer daarna alleen met een hint of tegenvraag.');
  } else if (behavior.discovery <= 30) {
    parts.push('Stap 1: benoem de twee variabelen. Stap 2: check of ze samen veranderen. Stap 3: zoek alternatieve verklaringen. Stap 4: vraag welk bewijs nodig is voor causaliteit.');
  }

  if (behavior.reflection >= 70) {
    parts.push('Welke denkfout zou je zelf het makkelijkst kunnen maken als je dit onderscheid vergeet?');
  }

  if (behavior.cognitiveChallenge >= 75) {
    parts.push('Verdieping: welke onderzoeksopzet zou sterker bewijs voor causaliteit geven dan alleen een correlatiecoëfficiënt?');
  } else if (behavior.cognitiveChallenge <= 25) {
    parts.push('Ezelsbrug: samen bewegen is nog niet hetzelfde als elkaar veroorzaken.');
  }

  if (behavior.certainty <= 30) {
    parts.push('In echte onderzoeken is causaliteit vaak gradueel onderbouwd; het hangt af van onderzoeksopzet, alternatieve verklaringen en de kwaliteit van het bewijs.');
  }

  if (behavior.responseLength <= 30) return parts.slice(0, 2).join(' ');
  if (behavior.responseLength <= 70) return parts.slice(0, 4).join('\n\n');
  return parts.join('\n\n');
}

export function generatePreviewDescription(behavior: BehaviorModel): string {
  const traits: string[] = [];
  if (behavior.responseType <= 35) traits.push('vragend');
  else if (behavior.responseType >= 65) traits.push('uitleggend');

  if (behavior.guidance <= 35) traits.push('uitdagend');
  else if (behavior.guidance >= 65) traits.push('ondersteunend');

  if (behavior.discovery >= 65) traits.push('ontdekkingsgericht');
  else if (behavior.discovery <= 35) traits.push('stapsgewijs');

  if (behavior.consensus <= 35) traits.push('kritisch toetsend');
  if (behavior.reflection >= 65) traits.push('reflectief');
  if (behavior.cognitiveChallenge >= 65) traits.push('cognitief uitdagend');

  return traits.length ? traits.join(', ') : 'gebalanceerd';
}

export function getBehaviorIntensity(behavior: BehaviorModel): number {
  const values = Object.values(behavior);
  const totalDifference = values.reduce((sum, value) => sum + Math.abs(value - 50), 0);
  return Math.round((totalDifference / values.length / 50) * 100);
}
