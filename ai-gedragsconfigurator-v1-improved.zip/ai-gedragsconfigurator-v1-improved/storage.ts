/**
 * Privacy-first lokale opslag voor gedragsconfiguraties.
 */

import { BehaviorModel, DEFAULT_BEHAVIOR, validateBehaviorModel } from './gedragsmodel';

const STORAGE_KEY = 'ai-behavior-config';
const STORAGE_VERSION = 1;

export interface StorageData {
  version: number;
  behavior: BehaviorModel;
  timestamp: number;
}

export function saveBehaviorConfig(behavior: BehaviorModel): void {
  if (!validateCompleteBehavior(behavior)) return;
  try {
    const data: StorageData = { version: STORAGE_VERSION, behavior, timestamp: Date.now() };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (error) {
    console.error('Failed to save behavior config:', error);
  }
}

export function loadBehaviorConfig(): BehaviorModel {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return DEFAULT_BEHAVIOR;

    const data = JSON.parse(stored) as Partial<StorageData>;
    if (data.version !== STORAGE_VERSION || !validateCompleteBehavior(data.behavior)) return DEFAULT_BEHAVIOR;
    return { ...data.behavior };
  } catch (error) {
    console.error('Failed to load behavior config:', error);
    return DEFAULT_BEHAVIOR;
  }
}

export function clearBehaviorConfig(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (error) {
    console.error('Failed to clear behavior config:', error);
  }
}

export function exportBehaviorConfig(behavior: BehaviorModel, filename?: string): void {
  if (!validateCompleteBehavior(behavior)) return;
  try {
    const data = { version: STORAGE_VERSION, behavior, exportedAt: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename || 'ai-gedragsconfiguratie.json';
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  } catch (error) {
    console.error('Failed to export behavior config:', error);
  }
}

export function importBehaviorConfig(file: File): Promise<BehaviorModel> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = String(event.target?.result ?? '');
        const data = JSON.parse(content);
        if (!validateCompleteBehavior(data?.behavior)) throw new Error('Invalid behavior configuration');
        resolve({ ...data.behavior });
      } catch {
        reject(new Error('Ongeldige configuratie')); 
      }
    };
    reader.onerror = () => reject(new Error('Configuratiebestand kon niet worden gelezen'));
    reader.readAsText(file);
  });
}

/**
 * URL-safe base64. encodeURIComponent voorkomt problemen met Unicode en
 * base64url voorkomt +, / en = in query parameters.
 */
function encodeConfig(behavior: BehaviorModel): string {
  const utf8 = unescape(encodeURIComponent(JSON.stringify(behavior)));
  return btoa(utf8).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function decodeConfig(encoded: string): unknown {
  const normalized = encoded.replace(/-/g, '+').replace(/_/g, '/');
  const padded = normalized + '='.repeat((4 - (normalized.length % 4)) % 4);
  const utf8 = atob(padded);
  return JSON.parse(decodeURIComponent(escape(utf8)));
}

export function generateShareableURL(behavior: BehaviorModel): string {
  if (!validateCompleteBehavior(behavior)) return window.location.href;
  try {
    const url = new URL(window.location.href);
    url.search = '';
    url.hash = '';
    url.searchParams.set('config', encodeConfig(behavior));
    return url.toString();
  } catch (error) {
    console.error('Failed to generate shareable URL:', error);
    return window.location.href;
  }
}

export function parseShareableURL(): BehaviorModel | null {
  try {
    const encoded = new URL(window.location.href).searchParams.get('config');
    if (!encoded) return null;
    const behavior = decodeConfig(encoded);
    return validateCompleteBehavior(behavior) ? { ...behavior } : null;
  } catch (error) {
    console.warn('Invalid shareable behavior URL:', error);
    return null;
  }
}

function validateCompleteBehavior(value: unknown): value is BehaviorModel {
  if (!value || typeof value !== 'object') return false;
  const behavior = value as Partial<BehaviorModel>;
  const keys: (keyof BehaviorModel)[] = [
    'creativity', 'guidance', 'responseType', 'practicality', 'responseLength', 'certainty',
    'consensus', 'pace', 'discovery', 'reflection', 'collaboration', 'cognitiveChallenge',
  ];
  return keys.every((key) => key in behavior) && validateBehaviorModel(behavior);
}

export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (error) {
    console.error('Failed to copy to clipboard:', error);
    return false;
  }
}
