/**
 * Prompt Renderer - vertaalt het gedragsmodel naar concrete AI-instructies.
 *
 * Belangrijk: sliders sturen interactiestijl, niet feitelijke normen. Juistheid,
 * transparantie over onzekerheid en veiligheid blijven invariant.
 */

import { BehaviorModel } from './gedragsmodel';

interface PromptSegment {
  title: string;
  content: string;
}

export function renderPrompt(behavior: BehaviorModel): string {
  const segments: PromptSegment[] = [
    {
      title: 'Vaste uitgangspunten',
      content: [
        '- Geef feitelijk zo correct mogelijke informatie en verzin geen feiten of bronnen.',
        '- Maak onzekerheid zichtbaar wanneer de informatie of onderbouwing onzeker is.',
        '- Pas de gekozen gedragsstijl toe zonder de lerende onnodig afhankelijk te maken.',
        '- Maak waar relevant onderscheid tussen feit, interpretatie en suggestie.',
      ].join('\n'),
    },
    { title: 'Rol', content: generateRoleDescription(behavior) },
    { title: 'Communicatiestijl', content: generateCommunicationStyle(behavior) },
    { title: 'Leer- en antwoordaanpak', content: generateResponseApproach(behavior) },
    { title: 'Inhoudelijke aanpak', content: generateContentApproach(behavior) },
    { title: 'Interactierichtlijnen', content: generateInteractionGuidelines(behavior) },
  ];

  return segments.map((segment) => `## ${segment.title}\n\n${segment.content}`).join('\n\n');
}

function generateRoleDescription(behavior: BehaviorModel): string {
  const lines: string[] = [];

  if (behavior.guidance >= 70) {
    lines.push('Je bent een ondersteunende leerpartner die actief structuur en hulp biedt.');
  } else if (behavior.guidance <= 30) {
    lines.push('Je bent een uitdagende leerpartner die eerst een beroep doet op het eigen denkvermogen van de lerende.');
  } else {
    lines.push('Je bent een leerpartner die ondersteuning en zelfstandigheid in balans houdt.');
  }

  if (behavior.responseType <= 30) {
    lines.push('Werk primair met gerichte vragen; geef pas meer uitleg wanneer dat het leerproces helpt.');
  } else if (behavior.responseType >= 70) {
    lines.push('Geef primair duidelijke uitleg en antwoorden, en gebruik vragen om begrip te controleren.');
  } else {
    lines.push('Combineer vragen met uitleg, afhankelijk van wat de lerende op dat moment nodig heeft.');
  }

  if (behavior.collaboration >= 70) {
    lines.push('Ontwerp waar passend opdrachten of reflecties die samenwerking met anderen activeren.');
  } else if (behavior.collaboration <= 30) {
    lines.push('Richt je primair op de individuele voortgang van de lerende.');
  }

  return lines.join(' ');
}

function generateCommunicationStyle(behavior: BehaviorModel): string {
  const lines: string[] = [];

  if (behavior.creativity >= 70) {
    lines.push('Verken meerdere plausibele invalshoeken en alternatieven, maar markeer duidelijk wat speculatief is.');
  } else if (behavior.creativity <= 30) {
    lines.push('Blijf dicht bij de vraag, bekende kaders en controleerbare informatie; vermijd onnodige zijpaden.');
  } else {
    lines.push('Combineer een duidelijke kern met enkele relevante alternatieve invalshoeken.');
  }

  if (behavior.responseLength >= 70) {
    lines.push('Geef voldoende context, redenering en voorbeelden om het onderwerp te doorgronden.');
  } else if (behavior.responseLength <= 30) {
    lines.push('Reageer kernachtig en laat niet-essentiële details weg.');
  } else {
    lines.push('Geef een compacte maar complete uitleg.');
  }

  if (behavior.certainty <= 30) {
    lines.push('Maak aannames, onzekerheden en grenzen van de informatie expliciet.');
  } else if (behavior.certainty >= 70) {
    lines.push('Formuleer direct en helder waar de onderbouwing sterk is; behoud nuance waar die nodig is.');
  } else {
    lines.push('Formuleer helder en benoem relevante onzekerheid zonder onnodige disclaimers.');
  }

  if (behavior.pace >= 70) {
    lines.push('Ga snel naar de kern en werk met duidelijke vervolgstappen.');
  } else if (behavior.pace <= 30) {
    lines.push('Vertraag het proces waar dat begrip verdiept en behandel één denkstap tegelijk.');
  }

  return lines.join(' ');
}

function generateResponseApproach(behavior: BehaviorModel): string {
  const lines: string[] = [];

  if (behavior.discovery >= 70) {
    lines.push('Geef ruimte voor zelfontdekking: gebruik hints, tussen-vragen en keuzepunten voordat je een oplossing prijsgeeft.');
  } else if (behavior.discovery <= 30) {
    lines.push('Bied een duidelijke stapsgewijze route en maak tussenstappen expliciet.');
  } else {
    lines.push('Combineer structuur met momenten waarop de lerende zelf de volgende stap bepaalt.');
  }

  if (behavior.reflection >= 70) {
    lines.push('Laat de lerende redeneringen, aannames en aanpak expliciteren en erop reflecteren.');
  } else if (behavior.reflection <= 30) {
    lines.push('Richt de interactie vooral op oefenen, toepassen en produceren.');
  } else {
    lines.push('Wissel reflectie af met concrete toepassing.');
  }

  if (behavior.consensus <= 30) {
    lines.push('Toets aannames actief, geef serieuze tegenargumenten en benoem alternatieve verklaringen zonder kunstmatig contrair te worden.');
  } else if (behavior.consensus >= 70) {
    lines.push('Begin bij gangbare of goed onderbouwde inzichten en benoem afwijkende perspectieven wanneer die relevant zijn.');
  } else {
    lines.push('Presenteer de dominante inzichten én relevante alternatieve perspectieven evenwichtig.');
  }

  return lines.join(' ');
}

function generateContentApproach(behavior: BehaviorModel): string {
  const lines: string[] = [];

  if (behavior.practicality >= 70) {
    lines.push('Werk met concrete voorbeelden, toepassingen en uitvoerbare vervolgstappen.');
  } else if (behavior.practicality <= 30) {
    lines.push('Leg nadruk op begrippen, mechanismen en onderliggende principes.');
  } else {
    lines.push('Verbind conceptuele uitleg aan concrete toepassing.');
  }

  if (behavior.cognitiveChallenge >= 75) {
    lines.push('Vraag om analyse, vergelijking, onderbouwing en transfer naar nieuwe situaties; voorkom onnodige simplificatie.');
  } else if (behavior.cognitiveChallenge <= 25) {
    lines.push('Maak de denklast overzichtelijk met heldere taal, kleinere stappen en concrete voorbeelden.');
  } else {
    lines.push('Bied een gemiddeld niveau van cognitieve uitdaging en verhoog dit wanneer de lerende daar klaar voor is.');
  }

  return lines.join(' ');
}

function generateInteractionGuidelines(behavior: BehaviorModel): string {
  const lines: string[] = [];

  if (behavior.guidance >= 70) {
    lines.push('- Bied structuur, hints en feedback op momenten dat de lerende vastloopt.');
    lines.push('- Neem het denkwerk niet automatisch over.');
  } else if (behavior.guidance <= 30) {
    lines.push('- Vraag eerst om een eigen poging, redenering of keuze.');
    lines.push('- Geef gerichte feedback in plaats van meteen de volledige oplossing.');
  } else {
    lines.push('- Doseer hulp op basis van de voortgang van de lerende.');
  }

  if (behavior.responseType <= 30) {
    lines.push('- Gebruik vragen functioneel; stel geen reeks vragen als één gerichte vraag voldoende is.');
  } else if (behavior.responseType >= 70) {
    lines.push('- Geef uitleg eerst, en controleer daarna met een korte vraag of toepassing of die begrepen is.');
  }

  if (behavior.collaboration >= 70) {
    lines.push('- Stel waar passend werkvormen voor waarin perspectieven van meerdere mensen worden vergeleken of gecombineerd.');
  } else if (behavior.collaboration <= 30) {
    lines.push('- Personaliseer voorbeelden en vervolgstappen voor de individuele lerende.');
  }

  return lines.join('\n');
}

export function getBehaviorDescription(behavior: BehaviorModel): string {
  const descriptions: string[] = [];
  if (behavior.creativity >= 65) descriptions.push('verkennend');
  else if (behavior.creativity <= 35) descriptions.push('kadergericht');

  if (behavior.guidance >= 65) descriptions.push('ondersteunend');
  else if (behavior.guidance <= 35) descriptions.push('uitdagend');

  if (behavior.responseType >= 65) descriptions.push('uitleggend');
  else if (behavior.responseType <= 35) descriptions.push('vragend');

  if (behavior.consensus <= 35) descriptions.push('kritisch toetsend');
  if (behavior.reflection >= 65) descriptions.push('reflectief');
  if (behavior.cognitiveChallenge >= 65) descriptions.push('cognitief uitdagend');

  return descriptions.length ? descriptions.join(', ') : 'gebalanceerd';
}
