/**
 * useBehaviorStore - React hook for managing behavior model state
 * 
 * This hook provides centralized state management for the behavior configuration,
 * including persistence to localStorage and preview generation.
 */

import { useEffect, useState, useCallback, createContext, useContext, ReactNode } from 'react';
import { BehaviorModel, DEFAULT_BEHAVIOR, SliderDimension } from '@/lib/gedragsmodel';
import { loadBehaviorConfig, saveBehaviorConfig, parseShareableURL } from '@/lib/storage';
import { generatePreviewConversation, ConversationMessage } from '@/lib/preview-generator';

interface UseBehaviorStoreReturn {
  // State
  behavior: BehaviorModel;
  preview: ConversationMessage[];
  isDirty: boolean;
  selectedRecipeId: string | null;

  // Actions
  updateBehavior: (updates: Partial<BehaviorModel>) => void;
  updateSlider: (dimension: SliderDimension, value: number) => void;
  resetBehavior: () => void;
  setBehavior: (behavior: BehaviorModel) => void;
  setSelectedRecipe: (recipeId: string | null) => void;
}

/**
 * Hook for managing behavior configuration state
 */
export function useBehaviorStore(): UseBehaviorStoreReturn {
  const [behavior, setBehaviorState] = useState<BehaviorModel>(DEFAULT_BEHAVIOR);
  const [preview, setPreview] = useState<ConversationMessage[]>([]);
  const [isDirty, setIsDirty] = useState(false);
  const [selectedRecipeId, setSelectedRecipeId] = useState<string | null>(null);
  const [isInitialized, setIsInitialized] = useState(false);

  // Initialize from localStorage or URL on mount
  useEffect(() => {
    // First, try to load from shareable URL
    const urlBehavior = parseShareableURL();
    if (urlBehavior) {
      setBehaviorState(urlBehavior);
      setPreview(generatePreviewConversation(urlBehavior));
      setIsInitialized(true);
      return;
    }

    // Otherwise, load from localStorage
    const savedBehavior = loadBehaviorConfig();
    setBehaviorState(savedBehavior);
    setPreview(generatePreviewConversation(savedBehavior));
    setIsInitialized(true);
  }, []);

  // Generate preview whenever behavior changes
  useEffect(() => {
    if (!isInitialized) return;
    setPreview(generatePreviewConversation(behavior));
  }, [behavior, isInitialized]);

  // Save to localStorage whenever behavior changes (debounced)
  useEffect(() => {
    if (!isInitialized) return;

    const timer = setTimeout(() => {
      saveBehaviorConfig(behavior);
    }, 500);

    return () => clearTimeout(timer);
  }, [behavior, isInitialized]);

  // Update entire behavior model
  const updateBehavior = useCallback((updates: Partial<BehaviorModel>) => {
    setBehaviorState(prev => ({
      ...prev,
      ...updates,
    }));
    setIsDirty(true);
    setSelectedRecipeId(null); // Clear recipe selection when manually editing
  }, []);

  // Update a single slider
  const updateSlider = useCallback((dimension: SliderDimension, value: number) => {
    setBehaviorState(prev => ({
      ...prev,
      [dimension]: Math.max(0, Math.min(100, value)),
    }));
    setIsDirty(true);
    setSelectedRecipeId(null); // Clear recipe selection when manually editing
  }, []);

  // Reset to defaults
  const resetBehavior = useCallback(() => {
    setBehaviorState(DEFAULT_BEHAVIOR);
    setPreview(generatePreviewConversation(DEFAULT_BEHAVIOR));
    setIsDirty(false);
    setSelectedRecipeId(null);
  }, []);

  // Set entire behavior model
  const setBehavior = useCallback((newBehavior: BehaviorModel) => {
    setBehaviorState(newBehavior);
    setPreview(generatePreviewConversation(newBehavior));
    setIsDirty(false);
  }, []);

  // Set selected recipe
  const setSelectedRecipeCallback = useCallback((recipeId: string | null) => {
    setSelectedRecipeId(recipeId);
  }, []);

  return {
    behavior,
    preview,
    isDirty,
    selectedRecipeId,
    updateBehavior,
    updateSlider,
    resetBehavior,
    setBehavior,
    setSelectedRecipe: setSelectedRecipeCallback,
  };
}

// Context for sharing behavior store across components

export interface BehaviorContextType extends UseBehaviorStoreReturn {}

const BehaviorContext = createContext<BehaviorContextType | undefined>(undefined);

export function BehaviorProvider({ children }: { children: ReactNode }) {
  const store = useBehaviorStore();

  return (
    <BehaviorContext.Provider value={store}>
      {children}
    </BehaviorContext.Provider>
  );
}

export function useBehavior(): BehaviorContextType {
  const context = useContext(BehaviorContext);
  if (!context) {
    throw new Error('useBehavior must be used within BehaviorProvider');
  }
  return context;
}
