/**
 * Drie pedagogische demonstratie-presets voor versie 1.
 *
 * Doel van V1: niet zoveel mogelijk use-cases aanbieden, maar zichtbaar maken
 * dat dezelfde AI bij dezelfde vraag anders kan handelen door menselijke ontwerpkeuzes.
 */

import { BehaviorModel } from './gedragsmodel';

export interface Recipe {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  behavior: BehaviorModel;
  educationalValue: string;
}

export const RECIPES: Recipe[] = [
  {
    id: 'socratic-tutor',
    name: 'Socratische Tutor',
    description: 'Activeert het denkproces door vooral vragen, hints en reflectie.',
    icon: '🎓',
    color: 'bg-blue-100 text-blue-900',
    behavior: {
      creativity: 45,
      guidance: 55,
      responseType: 12,
      practicality: 45,
      responseLength: 55,
      certainty: 35,
      consensus: 45,
      pace: 30,
      discovery: 85,
      reflection: 85,
      collaboration: 45,
      cognitiveChallenge: 72,
    },
    educationalValue: 'Laat zien hoe AI zelfstandig denken kan ondersteunen zonder meteen het antwoord over te nemen.',
  },
  {
    id: 'exam-prep',
    name: 'Examenvoorbereider',
    description: 'Werkt doelgericht met uitleg, oefening en gerichte feedback.',
    icon: '📚',
    color: 'bg-amber-100 text-amber-900',
    behavior: {
      creativity: 25,
      guidance: 72,
      responseType: 72,
      practicality: 82,
      responseLength: 58,
      certainty: 65,
      consensus: 72,
      pace: 78,
      discovery: 38,
      reflection: 35,
      collaboration: 25,
      cognitiveChallenge: 72,
    },
    educationalValue: 'Laat zien hoe dezelfde AI kan worden ingericht voor efficiënt oefenen, corrigeren en consolideren.',
  },
  {
    id: 'critical-sparring-partner',
    name: 'Kritische Sparringpartner',
    description: 'Test redeneringen, bevraagt aannames en brengt alternatieve perspectieven in.',
    icon: '⚖️',
    color: 'bg-purple-100 text-purple-900',
    behavior: {
      creativity: 62,
      guidance: 35,
      responseType: 38,
      practicality: 52,
      responseLength: 68,
      certainty: 38,
      consensus: 18,
      pace: 42,
      discovery: 70,
      reflection: 82,
      collaboration: 55,
      cognitiveChallenge: 88,
    },
    educationalValue: 'Laat zien hoe AI kan worden ontworpen om argumenten te beproeven in plaats van ze automatisch te bevestigen.',
  },
];

export function getRecipeById(id: string): Recipe | undefined {
  return RECIPES.find((recipe) => recipe.id === id);
}

export function getAllRecipes(): Recipe[] {
  return RECIPES;
}

export function searchRecipes(query: string): Recipe[] {
  const q = query.trim().toLowerCase();
  if (!q) return RECIPES;
  return RECIPES.filter(
    (recipe) => recipe.name.toLowerCase().includes(q) || recipe.description.toLowerCase().includes(q),
  );
}
