/**
 * RecipeSelector - Component for selecting and applying preset recipes
 * 
 * Design: Recipes are presented as interactive pills that can be clicked to apply.
 * The selected recipe is highlighted.
 */

import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { RECIPES } from '@/lib/recipes';

interface RecipeSelectorProps {
  selectedRecipeId: string | null;
  onSelectRecipe: (recipeId: string) => void;
}

export function RecipeSelector({ selectedRecipeId, onSelectRecipe }: RecipeSelectorProps) {
  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <CardTitle className="text-base">Recepten</CardTitle>
        <CardDescription>
          Kies een voorgemaakte configuratie of pas sliders handmatig aan
        </CardDescription>
      </CardHeader>

      <CardContent>
        <ScrollArea className="w-full">
          <div className="flex gap-2 pb-4">
            {RECIPES.map((recipe) => (
              <Button
                key={recipe.id}
                onClick={() => onSelectRecipe(recipe.id)}
                variant={selectedRecipeId === recipe.id ? 'default' : 'outline'}
                className="flex-shrink-0 whitespace-nowrap transition-all duration-200"
                title={recipe.educationalValue}
              >
                <span className="mr-1">{recipe.icon}</span>
                {recipe.name}
              </Button>
            ))}
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
