/**
 * Gedragsmodel - kernmodel voor de AI-Gedragsconfigurator
 *
 * Ontwerpprincipe: gedrag is primair; de prompt is een afgeleide.
 * Alle dimensies beschrijven voorkeuren in interactiestijl. Ze mogen nooit
 * feitelijke juistheid, veiligheid of transparantie overrulen.
 */

export type SliderDimension =
  | 'creativity'
  | 'guidance'
  | 'responseType'
  | 'practicality'
  | 'responseLength'
  | 'certainty'
  | 'consensus'
  | 'pace'
  | 'discovery'
  | 'reflection'
  | 'collaboration'
  | 'cognitiveChallenge';

export interface SliderConfig {
  id: SliderDimension;
  label: string;
  description: string;
  min: string;
  max: string;
  minLabel: string;
  maxLabel: string;
  icon?: string;
  educationalContext: string;
}

export interface BehaviorModel {
  /** 0 = strak binnen kaders, 100 = breed verkennend. Feitelijke juistheid blijft altijd een basisvoorwaarde. */
  creativity: number;
  /** 0 = veel zelfstandigheid vragen, 100 = veel ondersteuning bieden. */
  guidance: number;
  /** 0 = vooral vragen stellen, 100 = vooral antwoorden geven. */
  responseType: number;
  /** 0 = conceptueel/theoretisch, 100 = concreet/toegepast. */
  practicality: number;
  /** 0 = beknopt, 100 = uitgebreid. */
  responseLength: number;
  /** 0 = onzekerheid expliciet maken, 100 = direct formuleren waar de onderbouwing dat toelaat. */
  certainty: number;
  /** 0 = aannames actief bevragen, 100 = eerst gangbare inzichten en consensus weergeven. */
  consensus: number;
  /** 0 = verdiepend en bedachtzaam, 100 = snel en doelgericht. */
  pace: number;
  /** 0 = stapsgewijze begeleiding, 100 = ruimte voor zelfontdekking. */
  discovery: number;
  /** 0 = handelen/maken, 100 = reflecteren/doorgronden. */
  reflection: number;
  /** 0 = individueel leren, 100 = samenwerkend leren. */
  collaboration: number;
  /** 0 = laagdrempelig, 100 = cognitief veeleisend. */
  cognitiveChallenge: number;
}

export const DEFAULT_BEHAVIOR: BehaviorModel = {
  creativity: 50,
  guidance: 50,
  responseType: 50,
  practicality: 50,
  responseLength: 50,
  certainty: 50,
  consensus: 50,
  pace: 50,
  discovery: 50,
  reflection: 50,
  collaboration: 50,
  cognitiveChallenge: 50,
};

export const SLIDER_CONFIGS: SliderConfig[] = [
  {
    id: 'creativity',
    label: 'Verkenning',
    description: 'Hoe breed mag de AI alternatieven en nieuwe invalshoeken verkennen?',
    min: 'Kadergericht',
    max: 'Verkennend',
    minLabel: 'Strak binnen kaders',
    maxLabel: 'Breed & verkennend',
    icon: '🎨',
    educationalContext: 'Stuurt de ruimte voor alternatieven en originaliteit. Feitelijke juistheid blijft in beide standen een basisvoorwaarde.',
  },
  {
    id: 'guidance',
    label: 'Begeleiding',
    description: 'Hoeveel ondersteuning moet de AI actief bieden?',
    min: 'Zelfstandigheid',
    max: 'Ondersteuning',
    minLabel: 'Veel zelfstandigheid',
    maxLabel: 'Veel ondersteuning',
    icon: '🤝',
    educationalContext: 'Bepaalt hoeveel hulp de AI geeft voordat de lerende zelf een volgende stap moet zetten.',
  },
  {
    id: 'responseType',
    label: 'Interactie',
    description: 'Moet de AI vooral vragen stellen of vooral antwoorden geven?',
    min: 'Vragen',
    max: 'Antwoorden',
    minLabel: 'Vragend & Socratisch',
    maxLabel: 'Uitleggend & informatief',
    icon: '❓',
    educationalContext: 'Bepaalt of de AI vooral het denkproces activeert of juist informatie en uitleg aanbiedt.',
  },
  {
    id: 'practicality',
    label: 'Toepassing',
    description: 'Moet de AI vooral conceptueel of concreet en toegepast werken?',
    min: 'Conceptueel',
    max: 'Toegepast',
    minLabel: 'Theorie & concepten',
    maxLabel: 'Praktijk & toepassing',
    icon: '🔧',
    educationalContext: 'Bepaalt of de nadruk ligt op begrip van principes of op toepassing in concrete situaties.',
  },
  {
    id: 'responseLength',
    label: 'Antwoordlengte',
    description: 'Hoe beknopt of uitgebreid moet de AI reageren?',
    min: 'Beknopt',
    max: 'Uitgebreid',
    minLabel: 'Kort & kernachtig',
    maxLabel: 'Uitgebreid & verdiepend',
    icon: '📝',
    educationalContext: 'Bepaalt hoeveel context, uitleg en voorbeelden de AI standaard geeft.',
  },
  {
    id: 'certainty',
    label: 'Epistemische toon',
    description: 'Hoe expliciet moet de AI omgaan met onzekerheid?',
    min: 'Nuancerend',
    max: 'Direct',
    minLabel: 'Onzekerheid expliciet',
    maxLabel: 'Direct waar onderbouwd',
    icon: '✓',
    educationalContext: 'Stuurt de formulering, niet de waarheid. De AI mag nooit zekerder klinken dan de beschikbare onderbouwing rechtvaardigt.',
  },
  {
    id: 'consensus',
    label: 'Perspectief',
    description: 'Moet de AI aannames actief bevragen of eerst gangbare inzichten weergeven?',
    min: 'Kritisch toetsen',
    max: 'Gangbaar kader',
    minLabel: 'Aannames bevragen',
    maxLabel: 'Consensus eerst',
    icon: '⚖️',
    educationalContext: 'Bepaalt hoeveel kritisch tegengeluid de AI actief toevoegt. Kritiek is bedoeld om redeneringen te testen, niet om kunstmatig contrair te zijn.',
  },
  {
    id: 'pace',
    label: 'Tempo',
    description: 'Moet de AI vooral verdiepen of snel naar de kern bewegen?',
    min: 'Verdiepend',
    max: 'Doelgericht',
    minLabel: 'Bedachtzaam & verdiepend',
    maxLabel: 'Snel & doelgericht',
    icon: '⚡',
    educationalContext: 'Bepaalt de snelheid van voortgang zonder diepgang als minderwaardig of snelheid als oppervlakkig te framen.',
  },
  {
    id: 'discovery',
    label: 'Ontdekking',
    description: 'Hoeveel ruimte krijgt de lerende om zelf de volgende stap te ontdekken?',
    min: 'Stapsgewijs',
    max: 'Zelf ontdekken',
    minLabel: 'Stapsgewijze begeleiding',
    maxLabel: 'Ruimte voor zelfontdekking',
    icon: '🔍',
    educationalContext: 'Bepaalt of de AI het pad expliciet structureert of hints geeft en de lerende zelf laat ontdekken.',
  },
  {
    id: 'reflection',
    label: 'Reflectie',
    description: 'Moet de AI vooral handelen en maken of juist reflecteren en doorgronden stimuleren?',
    min: 'Handelen',
    max: 'Reflecteren',
    minLabel: 'Actie & productie',
    maxLabel: 'Reflectie & begrip',
    icon: '🧠',
    educationalContext: 'Bepaalt of de interactie vooral op productie of op metacognitie en begrip is gericht.',
  },
  {
    id: 'collaboration',
    label: 'Samenwerking',
    description: 'Richt de AI zich vooral op individueel of samenwerkend leren?',
    min: 'Individueel',
    max: 'Samenwerkend',
    minLabel: 'Individueel leren',
    maxLabel: 'Samenwerkend leren',
    icon: '👥',
    educationalContext: 'Bepaalt of suggesties en opdrachten worden ingericht voor één lerende of voor interactie met anderen.',
  },
  {
    id: 'cognitiveChallenge',
    label: 'Cognitieve uitdaging',
    description: 'Hoeveel denkwerk vraagt de AI van de lerende?',
    min: 'Toegankelijk',
    max: 'Uitdagend',
    minLabel: 'Laagdrempelig',
    maxLabel: 'Cognitief veeleisend',
    icon: '🧩',
    educationalContext: 'Bepaalt de complexiteit van vragen, tussenstappen en redeneringen. De instelling hoort passend te zijn bij het niveau en doel van de lerende.',
  },
];

export function getSliderConfig(dimension: SliderDimension): SliderConfig {
  const config = SLIDER_CONFIGS.find((c) => c.id === dimension);
  if (!config) throw new Error(`Unknown slider dimension: ${dimension}`);
  return config;
}

export function validateBehaviorModel(model: Partial<BehaviorModel>): boolean {
  return Object.values(model).every(
    (value) => typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 100,
  );
}

export function mergeBehaviorModel(partial: Partial<BehaviorModel>): BehaviorModel {
  return { ...DEFAULT_BEHAVIOR, ...partial };
}
