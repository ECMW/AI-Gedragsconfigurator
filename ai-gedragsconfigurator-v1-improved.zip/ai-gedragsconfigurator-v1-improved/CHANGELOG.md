# Review V1 — belangrijkste verbeteringen

Deze revisie houdt de configurator bewust klein: **ontwerpdemonstratie van menselijke regie**, geen uitgebreide producttool.

## Inhoudelijk gecorrigeerd
- **Ontdekking-slider rechtgezet.** In het oorspronkelijke model betekende `100 = zelfontdekking`, terwijl de zichtbare min/max-labels dit omkeerden. Dat kon gebruikers precies het tegenovergestelde laten instellen van wat de prompt uitvoerde.
- **Creativiteit vs. nauwkeurigheid ontkoppeld.** Feitelijke juistheid is geen instelbare voorkeur. De slider stuurt nu de ruimte voor verkenning, met juistheid als vaste basisvoorwaarde.
- **Zekerheid vervangen door epistemische toon.** Een slider mag een model niet instrueren om ongefundeerd stellig te klinken. Directheid is toegestaan waar bewijs sterk is; onzekerheid moet zichtbaar blijven waar nodig.
- **Consensus vs. kritiek genuanceerd.** Kritisch gedrag betekent aannames toetsen en alternatieven serieus onderzoeken, niet automatisch contrair zijn.
- **Tempo neutraal geformuleerd.** `Snel & oppervlakkig` is vervangen door `snel & doelgericht`; snelheid en diepgang zijn ontwerpkeuzes, geen kwaliteitslabels.
- **Ononderbouwde claim verwijderd.** De eerdere code stelde dat alle recepten gebaseerd waren op onderzoek en docentfeedback. Zonder onderliggende bronnen is dat niet verdedigbaar.

## Scope V1 aangescherpt
- Teruggebracht van 10 presets naar de drie demonstraties die in de V1-positionering centraal staan:
  1. Socratische Tutor
  2. Examenvoorbereider
  3. Kritische Sparringpartner
- Dit ondersteunt het kernprincipe: **dezelfde AI + dezelfde vraag + andere ontwerpkeuzes = zichtbaar ander gedrag**.

## Promptlaag verbeterd
- Vaste invarianten toegevoegd: feitelijke juistheid, geen verzonnen bronnen, transparantie over onzekerheid, onderscheid tussen feit/interpretatie/suggestie.
- Sliderwaarden sturen alleen interactiestijl en pedagogische aanpak; ze mogen de epistemische basisregels niet overrulen.
- Tekstfouten en onnatuurlijke formuleringen gecorrigeerd.

## Preview betrouwbaarder gemaakt
- Eén vaste gebruikersvraag voor alle configuraties. Daardoor komt het zichtbare verschil echt uit de gedragsconfiguratie en niet uit een veranderende voorbeeldvraag.
- Preview is expliciet een **gesimuleerde demonstratie**, geen model-call of garantie dat een LLM exact zo zal reageren.
- Voorbeeldinhoud is concreter en laat Socratisch, uitleggericht, kritisch en reflectief gedrag beter uit elkaar lopen.

## Technisch verbeterd
- URL-configuraties gebruiken URL-safe base64 en ondersteunen Unicode robuuster.
- Volledige validatie bij opslaan, importeren en delen.
- Minder duplicatie in validatielogica.

## Niet bewust toegevoegd
Geen accounts, analytics, LMS-koppeling, backend, model-API, testimonials of extra recepten. Dat zou de V1 van ontwerpdemonstratie richting productontwikkeling trekken.
